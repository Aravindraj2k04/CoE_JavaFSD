import 'dart:convert';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'leaderboard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(QuizApp());
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.cyan,
        scaffoldBackgroundColor: Colors.white,
      ),
      supportedLocales: [
        Locale('en', ''),
        Locale('ta', ''),
      ],
      localizationsDelegates: [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: UserDetailsScreen(),
    );
  }
}

class UserDetailsScreen extends StatefulWidget {
  @override
  _UserDetailsScreenState createState() => _UserDetailsScreenState();
}

class _UserDetailsScreenState extends State<UserDetailsScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  Locale _selectedLocale = Locale('en', '');

  void _changeLanguage(Locale locale) {
    setState(() {
      _selectedLocale = locale;
    });
  }

  void _submitDetails() {
    if (_nameController.text.isNotEmpty && _ageController.text.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => QuizScreen(
            name: _nameController.text,
            age: _ageController.text,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Localizations.override(
      context: context,
      locale: _selectedLocale,
      child: Builder(
        builder: (context) {
          var t = AppLocalizations.of(context);
          return Scaffold(
            appBar: AppBar(
              title: Text('Enter Your Details'),
              actions: [
                DropdownButton<Locale>(
                  value: _selectedLocale,
                  onChanged: (Locale? newLocale) {
                    if (newLocale != null) {
                      _changeLanguage(newLocale);
                    }
                  },
                  items: [
                    DropdownMenuItem(
                      value: Locale('en', ''),
                      child: Text('English'),
                    ),
                    DropdownMenuItem(
                      value: Locale('ta', ''),
                      child: Text('தமிழ்'),
                    ),
                  ],
                ),
                              IconButton(
                icon: Icon(Icons.leaderboard),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LeaderboardScreen()),
                  );
                },
              ),
            ],
          ),

              
              
              
          
            body: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextField(
                    controller: _nameController,
                    decoration: InputDecoration(labelText: t?.name ?? 'Name'),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: _ageController,
                    decoration: InputDecoration(labelText: t?.age ?? 'Age'),
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.cyan,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _submitDetails,
                    child: Text('Submit', style: TextStyle(fontSize: 18, color: Colors.white)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class QuizScreen extends StatefulWidget {
  final String name;
  final String age;

  QuizScreen({required this.name, required this.age});

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _currentQuestionIndex = 0;
  int _iqScore = 0;
  int _eqScore = 0;
  bool _quizCompleted = false;
  String _quote = "";
  List<Map<String, dynamic>> _questions = [];

  final List<Map<String, dynamic>> _allIQQuestions = [
    { "question": "What comes next in the sequence: 2, 4, 8, 16, ?", "answers": ["32", "24", "18", "64"], "correct": 0, "type": "IQ" },
    { "question": "If A = 1, B = 2, what is Z?", "answers": ["26", "24", "30", "50"], "correct": 0, "type": "IQ" },
    { "question": "Solve: 15 + 6 / 3", "answers": ["17", "19", "21", "23"], "correct": 1, "type": "IQ" },
    { "question": "Which shape has the most sides?", "answers": ["Hexagon", "Pentagon", "Octagon", "Square"], "correct": 2, "type": "IQ" },
    { "question": "Which number is missing? 3, 6, ?, 12, 15", "answers": ["8", "9", "7", "10"], "correct": 1, "type": "IQ" },
  ];

  final List<Map<String, dynamic>> _allEQQuestions = [
    { "question": "How do you handle a conflict with a friend?", "answers": ["Talk it out", "Ignore", "Shout", "Avoid"], "correct": 0, "type": "EQ" },
    { "question": "How do you comfort someone in distress?", "answers": ["Listen", "Give advice", "Ignore", "Leave"], "correct": 0, "type": "EQ" },
      { "question": "What do you do if someone criticizes you unfairly?", "answers": ["Get defensive", "Stay calm", "Argue", "Ignore them"], "correct": 1, "type": "EQ" },
    { "question": "How do you react to a stressful situation?", "answers": ["Take deep breaths", "Panic", "Blame others", "Avoid"], "correct": 0, "type": "EQ" },
    { "question": "What is the best way to resolve a misunderstanding?", "answers": ["Clarify politely", "Ignore it", "Get angry", "Blame the other person"], "correct": 0, "type": "EQ" },
  ];

  @override
  void initState() {
    super.initState();
    _selectRandomQuestions();
  }

  void _selectRandomQuestions() {
    _allIQQuestions.shuffle();
    _allEQQuestions.shuffle();
    _questions = [..._allIQQuestions.take(5), ..._allEQQuestions.take(5)];
    _questions.shuffle();
  }

  void _answerQuestion(int index) {
    if (_questions[_currentQuestionIndex]['correct'] == index) {
      _questions[_currentQuestionIndex]['type'] == "IQ" ? _iqScore++ : _eqScore++;
    }
    setState(() {
      if (_currentQuestionIndex < _questions.length - 1) {
        _currentQuestionIndex++;
      } else {
        _quizCompleted = true;
        _fetchMotivationalQuote();
        _submitScoresToFirebase();
      }
    });
  }

  void _submitScoresToFirebase() {
    FirebaseFirestore.instance.collection('users').add({
      'name': widget.name,
      'age': widget.age,
      'iqScore': _iqScore,
      'eqScore': _eqScore,
    });
  }

  Future<void> _fetchMotivationalQuote() async {
    final response = await http.get(Uri.parse('https://zenquotes.io/api/random'));
    if (response.statusCode == 200) {
      setState(() {
        _quote = jsonDecode(response.body)[0]['q'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_quizCompleted) {
      return Scaffold(
        appBar: AppBar(title: Text('Quiz Completed')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Congratulations, ${widget.name}!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 20),
                Text('Your IQ Score: $_iqScore', style: TextStyle(fontSize: 18)),
                Text('Your EQ Score: $_eqScore', style: TextStyle(fontSize: 18)),
                SizedBox(height: 20),
                Text('Motivational Quote:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text(_quote, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic)),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text('Quiz')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Question ${_currentQuestionIndex + 1}/${_questions.length}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              _questions[_currentQuestionIndex]['question'],
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ..._questions[_currentQuestionIndex]['answers'].asMap().entries.map((entry) {
              int index = entry.key;
              String answer = entry.value;
              return ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.cyan,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () => _answerQuestion(index),
                child: Text(answer, style: TextStyle(fontSize: 16, color: Colors.white)),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}