export interface Review {
    movieTitle: string;
    reviewer: string;
    genre: string;
    review: string;
    rating: number;
    profilePic: string;
  }
  