export interface Movie {
    id: number;
    title: string;
    description: string;
    poster: string;
    rating: number;
    genre: string; 
  }
  