import { Pipe, PipeTransform } from '@angular/core';
import { Movie } from '../model/movie';

@Pipe({
  name: 'genreFilter'
})
export class GenreFilterPipe implements PipeTransform {
  transform(movies: Movie[], selectedGenre: string): Movie[] {
    if (!selectedGenre || selectedGenre === 'All') {
      return movies; // Show all movies if no genre is selected
    }
    return movies.filter(movie => movie.genre === selectedGenre);
  }
}
