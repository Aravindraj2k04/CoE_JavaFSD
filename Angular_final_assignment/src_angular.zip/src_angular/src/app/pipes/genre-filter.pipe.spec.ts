import { GenreFilterPipe } from './genre-filter.pipe';

describe('GenreFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new GenreFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
