import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-review-form',
  templateUrl: './review-form.component.html',
  styleUrls: ['./review-form.component.css']
})
export class ReviewFormComponent {
  @Output() newReviewEvent = new EventEmitter<any>();

  newReview = {
    movieTitle: '',
    review: '',
    reviewer: '',
    genre: '',
    rating: ''
  };

  submitReview() {
    if (this.newReview.movieTitle && this.newReview.review && this.newReview.reviewer && this.newReview.genre && this.newReview.rating) {
      this.newReviewEvent.emit({ ...this.newReview });
      this.newReview = { movieTitle: '', review: '', reviewer: '', genre: '', rating: '' };
    }
  }
}
