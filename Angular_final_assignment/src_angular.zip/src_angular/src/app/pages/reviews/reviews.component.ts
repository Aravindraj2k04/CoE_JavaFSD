import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {
  preexistingReviews: any[] = [];
  newReviews: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchPreexistingReviews();
    this.loadNewReviews();
  }

  fetchPreexistingReviews() {
    this.http.get<any[]>('http://localhost:4500/reviews').subscribe(
      (data) => {
        this.preexistingReviews = data;
      },
      (error) => {
        console.error('Error fetching reviews:', error);
      }
    );
  }
  addReview(review: any) {
    this.newReviews.push(review);
    localStorage.setItem('reviews', JSON.stringify(this.newReviews));
  }

  loadNewReviews() {
    const storedReviews = JSON.parse(localStorage.getItem('reviews') || '[]');
    this.newReviews = storedReviews;
  }
  clearReviews() {
    localStorage.removeItem('reviews');
    this.newReviews = []; // Reset reviews list
  }
  
}
