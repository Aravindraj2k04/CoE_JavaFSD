import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuBarComponent } from './common/menu-bar/menu-bar.component';
import { HomeComponent } from './pages/home/home.component';
import { ReviewsComponent } from './pages/reviews/reviews.component';
import { AboutComponent } from './pages/about/about.component';
import { ReviewCardComponent } from './components/review-card/review-card.component';
import { GenreFilterPipe } from './pipes/genre-filter.pipe';
import { FormsModule } from '@angular/forms';
import { ReviewFormComponent } from './components/review-form/review-form.component';
import { LoginComponent } from './pages/login/login.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    MenuBarComponent,
    HomeComponent,
    ReviewsComponent,
    AboutComponent,
    ReviewCardComponent,
    GenreFilterPipe,
    ReviewFormComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule,
    FormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
